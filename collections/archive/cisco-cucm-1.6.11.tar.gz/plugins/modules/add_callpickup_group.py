#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: cisco.cucm.add_callpickup_group
short_description: This module adds a new CP
description: This module adds a new Callpickup group (CP) to the CUCM server
version_added: "1.6.10"
options:
  name:
    description: name of the CP
    required: true
    type: str
  number:
    description: Callpick Group extension
    required: true
    type: str
  description:
    description: Description of the CP
    required: false
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
"""

EXAMPLES = r"""
- name: Add new CP
  cisco.cucm.add_callpickup_group:
    name: "CP_1201"
    number: "12010"
    description: "Test CP"
    provider:
      host: "cucm.my-domain.net"
      user: "admin"
      password: "my_super_pass"
      port: "8443"
      validate_certs: "false"
  delegate_to: localhost
  register: add_cp_results
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample:
    raw_content: ""
changed:
  description: True if changes were made onto the CUCM server
  type: str
  sample:
    changed: true
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        description=dict(type="str", required=False),
        name=dict(type="str", required=True),
        number=dict(type="str", required=True),
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
            required=True,
        ),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task

    result = dict(
        changed="",
        raw_content="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode

    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications

    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
   <soapenv:Header/>
   <soapenv:Body>
      <ns:addCallPickupGroup>
         <callPickupGroup>
            <pattern>{module.params['number']}</pattern>
            <description>{module.params['description']}</description>
            <name>{module.params['name']}</name>
         </callPickupGroup>
      </ns:addCallPickupGroup>
   </soapenv:Body>
</soapenv:Envelope>
"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    if response.status_code == 200:
        result["changed"] = True
    else:
        result["changed"] = False
        root = ET.fromstring(response.content)
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""ERROR: The CP pattern is already present""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results

    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
