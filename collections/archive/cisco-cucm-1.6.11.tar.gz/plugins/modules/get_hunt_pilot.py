#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: cisco.cucm.get_hunt_pilot
short_description: Given a HP, this module returns it's associated HL & CP
description: 
  - Given a Hunt Pilot (HP), this module returns it's associated Hunt List (HL) and Call Pickup group (CP) if the provided HP was found. If not, the module fails.
version_added: "1.6.0"
options:
  hunt_pilot:
    description: Hunt Pilot search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
"""

EXAMPLES = r"""
- name: Get CP & HL from Hunt Pilot
  cisco.cucm.get_hunt_pilot:
    hunt_pilot: "12010"
    provider:
      host: "cucm.my-domain.net"
      user: "admin"
      password: "my_super_pass"
      port: "8443"
      validate_certs: "false"
  delegate_to: localhost
  register: get_hunt_pilot_results
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample: 
    raw_content: "<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getHuntPilotResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><huntPilot uuid=\"{51ADE3C4-B1DF-2FC9-0957-02FD579ECF27}\"><description>Test #A08 - DST Office Hunt Pilot</description><huntListName uuid=\"{34759A42-46DF-1D1F-654A-53D4CF65A1CF}\">HL_1208_9XXXXXXXX</huntListName><callPickupGroupName uuid=\"{AFF1F1AF-4E9F-0901-DE37-E93E67BE424E}\">CP_12080</callPickupGroupName></huntPilot></return></ns:getHuntPilotResponse></soapenv:Body></soapenv:Envelope>"
call_pickup_group:
  description: The Call Pickup Group associated to the Hunt Pilot
  type: str
  sample:
    call_pickup_group: "CP_12080"
hunt_list:
  description: The Hunt List associated to the Hunt Pilot
  type: str
  sample:
    hunt_list: "HL_1208_9XXXXXXXX"
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        hunt_pilot=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        raw_content="",
        hunt_list="",
        call_pickup_group="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
      <soapenv:Body>
          <ns:getHuntPilot sequence="?">
            <pattern>{module.params["hunt_pilot"]}</pattern>
            <!--Optional:-->
            <returnedTags uuid="?">
                <description>?</description>
                <huntListName uuid="?">?</huntListName>
                <callPickupGroupName uuid="?">?</callPickupGroupName>
            </returnedTags>
          </ns:getHuntPilot>
      </soapenv:Body>
    </soapenv:Envelope>"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content

    root = ET.fromstring(response.content)
    
    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    try:
      result["hunt_list"] = root.find(".//*/huntListName").text
      result["call_pickup_group"] = root.find(".//*/callPickupGroupName").text
    except:
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""Type X Error: There is not any List Hunt Pilot associated to this Line Group""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
