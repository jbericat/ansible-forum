#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: cisco.cucm.get_user_devices
short_description: >-
  Given a User ID, this module returns it's associated Phone Devices
description: >-
  Given a User ID, this module returns it's associated Phone Devices.
  If the User ID is not present, the module fails
version_added: "1.6.0"
options:
  user_id:
    description: User search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
"""

EXAMPLES = r"""
- name: Get user associated Device Phones
  cisco.cucm.get_user_devices:
    user_id: "a00001"
    provider:
      host: "cucm.my-domain.net"
      user: "admin"
      password: "my_super_pass"
      port: "8443"
      validate_certs: "false"
  delegate_to: localhost
  register: get_user_devices_results
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample: 
    raw_content: "<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getUserResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><user uuid=\"{53347A1F-AFA0-0BC0-A6DD-E7AABC051C11}\"><associatedDevices><device>J10008a000008</device></associatedDevices></user></return></ns:getUserResponse></soapenv:Body></soapenv:Envelope>"
user_devices:
  description: List of Device Phone names associated to the provided User ID
  type: list
  sample:
    user_devices:
      - J10001a000001
      - J10002a000002
      - J10003a000003
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        user_id=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        raw_content="",
        user_devices="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
        <soapenv:Body>
            <ns:getUser sequence="?">
              <userid>{module.params["user_id"]}</userid>
              <!--Optional:-->
              <returnedTags uuid="?">
                  <!--Optional:-->
                  <associatedDevices>
                    <!--Zero or more repetitions:-->
                    <device>?</device>
                  </associatedDevices>
              </returnedTags>
            </ns:getUser>
        </soapenv:Body>
      </soapenv:Envelope>"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    root = ET.fromstring(response.content)

    try:
        xpath_query = ".//return/user/associatedDevices/device"
        user_associated_devices = root.findall(xpath_query)  
        
        results_list = []
        for device in user_associated_devices:
          results_list.append(device.text)
          
        result["user_devices"] = results_list
        
    except:
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""Error: The provided user-id does not exist""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
