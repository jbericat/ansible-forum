# Ansible Collection - cisco.cucm

# Description

This CUCM Ansible Galaxy Collection is a custom set of python modules designed to simplify the administration of Cisco Unified Communications Manager (CUCM) 12.5 platform features. These modules leverage the SOAP AXL (Administrative XML) interface provided by CUCM, enabling seamless automation of various tasks and configurations within the CUCM environment.

## Author
Jordi Bericat Ruz <jbericat@externos.abanca.com>
Automatizaciones CGR - ABANCA

## TO-DO

- Error messages can be unspecific on some module -this will be fixed on next releases
