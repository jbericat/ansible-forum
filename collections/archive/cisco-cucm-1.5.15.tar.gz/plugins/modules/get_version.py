#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: get_version
short_description: Gather CUCM Server version
description:
  - Given a CUCM host, this module retrieves it's version.
version_added: "1.0.0"
extends_documentation_fragment:
  - cisco.cucm.common
author: Jordi Bericat (@jordi-bericat_nttltd)
"""

EXAMPLES = r"""
- name: Get CUCM server version
  cisco.cucm.get_version:
    provider:
      host: cucm.my-domain.net
      user: admin
      password: my_super_pass
      port: 8443
      validate_certs: false
  delegate_to: localhost
  register: cucm_version

- name: Get cucm server version via an ssh tunneled connection
  cisco.cucm.get_version:
    provider: "{{ cucm_provider }}"
  delegate_to: "{{ delegated_host }}"
  register: cucm_version
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample: ["<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getCCMVersionResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><componentVersion><version>12.5.1.14900(63)</version></componentVersion></return></ns:getCCMVersionResponse></soapenv:Body></soapenv:Envelope>"]
version:
  description: Version release number of the CUCM Server
  type: str
  sample: {"version": "12.5.1.14900(63)"}
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(changed=False, raw_content="", version="")

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + provider_data["port"]
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
        <soapenv:Body>
            <ns:getCCMVersion>
            </ns:getCCMVersion>
        </soapenv:Body>
      </soapenv:Envelope>"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    root = ET.fromstring(response.content)

    try:
        version_element = root.find(".//componentVersion/version")
        result["version"] = version_element.text
    except:
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        module.fail_json(
            msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
            **result,
        )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
