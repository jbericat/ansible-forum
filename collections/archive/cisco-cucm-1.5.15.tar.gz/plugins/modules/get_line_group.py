#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: get_line_group
short_description: Lists the Line Groups existing on the CUCM server
description: 
  - Given a Directory Number, this module returns all of it's associated Line Groups.
version_added: "1.4.0"
options:
  directory_number:
    description: Line Group search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
notes:
  - Future versions will include extended return data.
author: Jordi Bericat (@jordi-bericat_nttltd)
"""

EXAMPLES = r"""
- name: Get Line Groups given a Directory Number
  cisco.cucm.get_line_group:
    directory_number: "10001"
    provider:
      host: cucm.my-domain.net
      user: admin
      password: my_super_pass
      port: 8443
      validate_certs: false
  delegate_to: localhost
  register: cucm_line_group

- name: Get Line Group given a Directory Number via an ssh tunneled connection
  cisco.cucm.get_line_group:
    directory_number: "10001"
    provider: "{{ cucm_provider }}"
  delegate_to: "{{ delegated_host }}"
  register: cucm_line_group
"""

RETURN = r"""
name:
  description: Line Group name
  type: string
  sample: {"line_group": "LG_1101_9XXXXXXXX"}
  returned: success
members:
  description: Line Group Directory Number members
  type: list
  sample: {"members":["10000","10001"]}
  returned: success
raw_content_name:
  description: The raw xml response received from the SOAP AXL request used to retrieve the Line Group name
  type: str
  returned: always
  sample: ["<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:executeSQLQueryResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><row><linegroup>LG_1101_9XXXXXXXX</linegroup><dn>10001</dn><station>J10001a000001</station></row></return></ns:executeSQLQueryResponse></soapenv:Body></soapenv:Envelope>"]
raw_content_members:
  description: The raw xml response received from the SOAP AXL request used to retrieve the Line Group name
  type: str
  returned: always
  sample: ["<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getLineGroupResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><lineGroup uuid=\"{4CE8096E-34B5-B14A-3F30-2A08CB975D66}\"><distributionAlgorithm>Longest Idle Time</distributionAlgorithm><rnaReversionTimeOut>10</rnaReversionTimeOut><huntAlgorithmNoAnswer>Try next member; then, try next group in Hunt List</huntAlgorithmNoAnswer><huntAlgorithmBusy>Try next member; then, try next group in Hunt List</huntAlgorithmBusy><huntAlgorithmNotAvailable>Try next member; then, try next group in Hunt List</huntAlgorithmNotAvailable><members><member uuid=\"{A37D5C91-8D82-9392-6FCC-13511E5F90CA}\"><lineSelectionOrder>0</lineSelectionOrder><directoryNumber uuid=\"{3945F993-89E2-2301-A0E6-528E32744A77}\"><pattern>10000</pattern><routePartitionName/></directoryNumber></member><member uuid=\"{91890E5A-7DE4-0EFB-29DA-210F6D1AB525}\"><lineSelectionOrder>1</lineSelectionOrder><directoryNumber uuid=\"{992218E0-D513-FB04-7B39-E28A34607D45}\"><pattern>10001</pattern><routePartitionName/></directoryNumber></member></members><name>LG_1101_9XXXXXXXX</name><autoLogOffHunt>false</autoLogOffHunt></lineGroup></return></ns:getLineGroupResponse></soapenv:Body></soapenv:Envelope>"]
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        directory_number=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        raw_content_name="",
        raw_content_members="",
        name="",
        members="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    ###################################
    # REQUEST 1 - GET LINE GROUP NAME #
    ###################################

    data_lg_name = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
      <soapenv:Body>
        <ns:executeSQLQuery>
          <sql>
            select lg.name as LineGroup,n.dnorpattern as DN, d.name as Station from linegroup lg
            inner join linegroupnumplanmap lgmap on lgmap.fklinegroup=lg.pkid
            inner join numplan n on lgmap.fknumplan=n.pkid
            inner join devicenumplanmap as dmap on dmap.fknumplan=n.pkid
            inner join device d on dmap.fkdevice=d.pkid
            where n.dnorpattern = "{ module.params["directory_number"] }"
          </sql>
        </ns:executeSQLQuery>
      </soapenv:Body>
    </soapenv:Envelope>"""

    response_lg_name = requests.post(
        url,
        data=data_lg_name,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content_name"] = response_lg_name.content

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    root_name = ET.fromstring(response_lg_name.content)
    lg_name_parameters = [
        {
            "option": "name",
            "xpath_query": ".//return/row[1]/linegroup",
        },
    ]

    try:
        for item in lg_name_parameters:
            lg_name_option = root_name.find(item["xpath_query"])
            result[item["option"]] = lg_name_option.text
    except:
        axl_error_code = root_name.find(".//axlcode")
        axl_error_message = root_name.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""Type X Error: There is not any Line Group associated to this Directory Number""",
                **result,
            )

    ######################################
    # REQUEST 2 - GET LINE GROUP MEMBERS #
    ######################################

    data_lg_members = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
      <soapenv:Body>
        <ns:getLineGroup>
          <name>{ lg_name_option.text }</name>
        </ns:getLineGroup>
      </soapenv:Body>
    </soapenv:Envelope>
    """

    response_lg_members = requests.post(
        url,
        data=data_lg_members,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content_members"] = response_lg_members.content

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    root_members = ET.fromstring(response_lg_members.content)
    lg_members_parameters = [
        {
            "option": "members",
            "xpath_query": ".//return/lineGroup/members/member/directoryNumber/pattern",
        },
    ]

    try:
        for item in lg_members_parameters:
            lg_members_option = root_members.findall(item["xpath_query"])
            result[item["option"]] = [
                pattern.text for pattern in lg_members_option
            ]
    except:
        axl_error_code = root_members.find(".//axlcode")
        axl_error_message = root_members.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )

        # DEBUG: I DON'T THINK WE NEED TO CHECK FOR ERRORS HERE; REVIEW ONCE THE MODULE IS FINISHED

        else:
            module.fail_json(
                msg=f"""Type X Error: NO MEMBERS""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
