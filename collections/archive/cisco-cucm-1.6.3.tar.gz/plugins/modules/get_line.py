#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: cisco.cucm.get_line
short_description: Returns UL given a DN
description: 
  - Given a Directory Number (DN), this module returns it's associated User Line (UL) current configuration parameters.
version_added: "1.2.0"
options:
  directory_number:
    description: User Line search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
notes:
  - Future versions may include return data in a dictionary.
author: Jordi Bericat (@jordi-bericat_nttltd)
"""

EXAMPLES = r"""
- name: Get User Line
  cisco.cucm.get_line:
    directory_number: 10001
    provider:
      host: cucm.my-domain.net
      user: admin
      password: my_super_pass
      port: 8443
      validate_certs: false
  delegate_to: localhost
  register: cucm_user_line
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample: ["<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getLineResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><line uuid=\"{BF729452-294F-BB94-F3AA-1635B4840BCA}\"><pattern>10001</pattern><description> TEST #A01 - Directory Number </description><usage>Device</usage><routePartitionName/><aarNeighborhoodName/><aarDestinationMask /><aarKeepCallHistory>true</aarKeepCallHistory><aarVoiceMailEnabled>false</aarVoiceMailEnabled><callForwardAll><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><secondaryCallingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination /></callForwardAll><callForwardBusy><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardBusy><callForwardBusyInt><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardBusyInt><callForwardNoAnswer><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination /><duration /></callForwardNoAnswer><callForwardNoAnswerInt><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination /><duration /></callForwardNoAnswerInt><callForwardNoCoverage><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardNoCoverage><callForwardNoCoverageInt><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardNoCoverageInt><callForwardOnFailure><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination /></callForwardOnFailure><callForwardAlternateParty><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination /><duration /></callForwardAlternateParty><callForwardNotRegistered><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardNotRegistered><callForwardNotRegisteredInt><forwardToVoiceMail>false</forwardToVoiceMail><callingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><destination>11010</destination></callForwardNotRegisteredInt><callPickupGroupName uuid=\"{2ACB60D5-629B-C83C-4BDF-3E2CF275DDE4}\">CP_11010</callPickupGroupName><autoAnswer>Auto Answer Off</autoAnswer><networkHoldMohAudioSourceId /><userHoldMohAudioSourceId /><callingIdPresentationWhenDiverted>Default</callingIdPresentationWhenDiverted><alertingName/><asciiAlertingName/><presenceGroupName uuid=\"{AD243D17-98B4-4118-8FEB-5FF2E1B781AC}\">Standard Presence group</presenceGroupName><shareLineAppearanceCssName/><voiceMailProfileName/><patternPrecedence>Default</patternPrecedence><releaseClause>No Error</releaseClause><hrDuration /><hrInterval /><cfaCssPolicy>Use System Default</cfaCssPolicy><defaultActivatedDeviceName/><parkMonForwardNoRetrieveDn /><parkMonForwardNoRetrieveIntDn /><parkMonForwardNoRetrieveVmEnabled>false</parkMonForwardNoRetrieveVmEnabled><parkMonForwardNoRetrieveIntVmEnabled>false</parkMonForwardNoRetrieveIntVmEnabled><parkMonForwardNoRetrieveCssName/><parkMonForwardNoRetrieveIntCssName/><parkMonReversionTimer /><partyEntranceTone>Default</partyEntranceTone><directoryURIs/><allowCtiControlFlag>true</allowCtiControlFlag><rejectAnonymousCall>false</rejectAnonymousCall><patternUrgency>false</patternUrgency><confidentialAccess><confidentialAccessMode /><confidentialAccessLevel>-1</confidentialAccessLevel></confidentialAccess><externalCallControlProfile/><enterpriseAltNum><numMask /><isUrgent>f</isUrgent><addLocalRoutePartition>f</addLocalRoutePartition><routePartition/><advertiseGloballyIls>f</advertiseGloballyIls></enterpriseAltNum><e164AltNum><numMask /><isUrgent>f</isUrgent><addLocalRoutePartition>f</addLocalRoutePartition><routePartition/><advertiseGloballyIls>f</advertiseGloballyIls></e164AltNum><pstnFailover /><callControlAgentProfile /><associatedDevices><device>J10001a000001</device></associatedDevices><useEnterpriseAltNum>false</useEnterpriseAltNum><useE164AltNum>false</useE164AltNum><active>true</active><externalPresentationInfo><presentationInfo><externalPresentationNumber/><externalPresentationName/></presentationInfo><isAnonymous>f</isAnonymous></externalPresentationInfo></line></return></ns:getLineResponse></soapenv:Body></soapenv:Envelope>"]
call_forward_busy_int:
  description: TBD
  type: str
  sample: {"call_forward_busy_int": "1110001"}
  returned: success
call_forward_busy_ext:
  description: TBD
  type: str
  sample: {"call_forward_busy_ext": "1110001"}
  returned: success
call_forward_no_coverage_int:
  description: TBD
  type: str
  sample: {"call_forward_no_coverage_int": "1110001"}
  returned: success
call_forward_no_coverage_ext:
  description: TBD
  type: str
  sample: {"call_forward_no_coverage_ext": "1110001"}
  returned: success
call_forward_unregistered_int:
  description: TBD
  type: str
  sample: {"call_forward_unregistered_int": "11010"}
  returned: success
call_forward_unregistered_ext:
  description: TBD
  type: str
  sample: {"call_forward_unregistered_ext": "11010"}
  returned: success
call_pickup_group:
  description: TBD
  type: str
  sample: {"call_pickup_group": "CP_11010"}
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        directory_number=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        raw_content="",
        call_forward_busy_int="",
        call_forward_busy_ext="",
        call_forward_no_coverage_int="",
        call_forward_no_coverage_ext="",
        call_forward_unregistered_int="",
        call_forward_unregistered_ext="",
        call_pickup_group="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
        <soapenv:Body>
          <ns:getLine>
            <pattern>{ module.params["directory_number"] }</pattern>
          </ns:getLine>
      </soapenv:Body>
    </soapenv:Envelope>"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content
    root = ET.fromstring(response.content)
    ul_parameters = [
        {
            "option": "call_forward_busy_int",
            "xpath_query": ".//return/line/callForwardBusyInt/destination",
        },
        {
            "option": "call_forward_busy_ext",
            "xpath_query": ".//return/line/callForwardBusy/destination",
        },
        {
            "option": "call_forward_no_coverage_int",
            "xpath_query": ".//return/line/callForwardNoCoverageInt/destination",
        },
        {
            "option": "call_forward_no_coverage_ext",
            "xpath_query": ".//return/line/callForwardNoCoverage/destination",
        },
        {
            "option": "call_forward_unregistered_int",
            "xpath_query": ".//return/line/callForwardNotRegisteredInt/destination",
        },
        {
            "option": "call_forward_unregistered_ext",
            "xpath_query": ".//return/line/callForwardNotRegistered/destination",
        },
        {
            "option": "call_pickup_group",
            "xpath_query": ".//return/line/callPickupGroupName",
        },
    ]

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    try:
        for item in ul_parameters:
            ul_option = root.find(item["xpath_query"])
            result[item["option"]] = ul_option.text
    except:
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""Type X Error: There is not any UL associated to this Directory Number""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
