# CHANGELOG

## version 0.0.1

- Added template for further module development ´get_version.py´
- Added module ´get_phone.py´
- Init galaxy collection structure
