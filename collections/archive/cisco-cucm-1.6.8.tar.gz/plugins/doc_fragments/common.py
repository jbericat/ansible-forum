# -*- coding: utf-8 -*-

# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function
__metaclass__ = type

class ModuleDocFragment(object):
  # Standard documentation fragment
  DOCUMENTATION = r"""
  author: 
      - Jordi Bericat (jordi.bericat@global.ntt)
      - Adrián Portas (luisadrian.portas@global.ntt)
  options:
    provider:
      description: Dictionary object containing connection details
      required: true
      type: dictionary
      suboptions:
        host:
          description: The CUCM Server hostname or IP
          required: true
          type: str
        user:
          description: The username to connect to the CUCM AXL endpoint with
          required: true
          type: str
        password:
          description: The password for the user account used to connect to the CUCM AXL endpoint
          required: true
          type: str
          no_log: true
        port:
          description: The CUCM AXL endpoint server port
          required: false
          type: str
          default: 8443
        validate_certs:
          description: If false, SSL certificates are not validated. Use this only on personally controlled sites using self-signed certificates
          required: false
          type: str
          default: "true"
  notes:
  - Future versions may include extended return data
  """
