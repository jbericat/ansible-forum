#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module:  cisco.cucm.get_phone_line
short_description: Returns the Phone Device's primary DN
description: 
  - Given a Phone Device Name, this module retrieves the primary Directory Number (DN) of its associated User Line (UL).
version_added: "1.1.0"
options:
  device_name:
    description: Phone Device search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
notes:
  - Future versions will include extended return data, as well as the ability to query by DN.
author: Jordi Bericat (@jordi-bericat_nttltd)
"""

EXAMPLES = r"""
- name: Get user Phone Device
  cisco.cucm.get_phone_line:
    device_name: "J10001a000001"
    provider:
      host: cucm.my-domain.net
      user: admin
      password: my_super_pass
      port: 8443
      validate_certs: false
  delegate_to: localhost
  register: cucm_phone
"""

RETURN = r"""
raw_content:
  description: The raw xml response received from the CUCM server
  type: str
  returned: always
  sample: ["<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getPhoneResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><phone ctiid=\"140\" uuid=\"{48B72596-AE04-036E-06B9-D121BCC4EB32}\"><name>J10001a000001</name><description>TEST #A01 - Phone</description><product>Cisco Unified Client Services Framework</product><model>Cisco Unified Client Services Framework</model><class>Phone</class><protocol>SIP</protocol><protocolSide>User</protocolSide><callingSearchSpaceName/><devicePoolName uuid=\"{1B1B9EB6-7803-11D3-BDF0-00108302EAD1}\">Default</devicePoolName><commonDeviceConfigName/><commonPhoneConfigName uuid=\"{AC243D17-98B4-4118-8FEB-5FF2E1B781AC}\">Standard Common Phone Profile</commonPhoneConfigName><networkLocation>Use System Default</networkLocation><locationName uuid=\"{29C5C1C4-8871-4D1E-8394-0B9181E8C54D}\">Hub_None</locationName><mediaResourceListName/><networkHoldMohAudioSourceId /><userHoldMohAudioSourceId /><automatedAlternateRoutingCssName/><aarNeighborhoodName/><loadInformation special=\"false\"/><vendorConfig /><versionStamp>{1686611472-0429F197-7E34-44EE-9F49-12782AA87E13}</versionStamp><traceFlag>false</traceFlag><mlppDomainId /><mlppIndicationStatus>Off</mlppIndicationStatus><preemption>Disabled</preemption><useTrustedRelayPoint>Default</useTrustedRelayPoint><retryVideoCallAsAudio>true</retryVideoCallAsAudio><securityProfileName uuid=\"{C6085E14-A32C-4C5E-A3D1-8DAF60D81594}\">Cisco Unified Client Services Framework - Standard SIP Non-Secure Profile</securityProfileName><sipProfileName uuid=\"{FCBC7581-4D8D-48F3-917E-00B09FB39213}\">Standard SIP Profile</sipProfileName><cgpnTransformationCssName/><useDevicePoolCgpnTransformCss>true</useDevicePoolCgpnTransformCss><geoLocationName/><geoLocationFilterName/><sendGeoLocation>false</sendGeoLocation><lines><line uuid=\"{04D6C5A7-F53E-5854-4D0B-CF53059CD26C}\"><index>1</index><label/><display/><dirn uuid=\"{BF729452-294F-BB94-F3AA-1635B4840BCA}\"><pattern>10001</pattern><routePartitionName/></dirn><ringSetting>Ring</ringSetting><consecutiveRingSetting>Use System Default</consecutiveRingSetting><ringSettingIdlePickupAlert /><ringSettingActivePickupAlert /><displayAscii/><e164Mask /><dialPlanWizardId /><mwlPolicy>Use System Policy</mwlPolicy><maxNumCalls>2</maxNumCalls><busyTrigger>1</busyTrigger><callInfoDisplay><callerName>true</callerName><callerNumber>false</callerNumber><redirectedNumber>false</redirectedNumber><dialedNumber>true</dialedNumber></callInfoDisplay><recordingProfileName/><monitoringCssName/><recordingFlag>Call Recording Disabled</recordingFlag><audibleMwi>Default</audibleMwi><speedDial /><partitionUsage>General</partitionUsage><associatedEndusers/><missedCallLogging>true</missedCallLogging><recordingMediaSource>Gateway Preferred</recordingMediaSource></line></lines><numberOfButtons>8</numberOfButtons><phoneTemplateName uuid=\"{8E1A10FA-A52C-4435-A4EC-540D266C8C37}\">Standard Client Services Framework</phoneTemplateName><speeddials/><busyLampFields/><primaryPhoneName/><ringSettingIdleBlfAudibleAlert>Default</ringSettingIdleBlfAudibleAlert><ringSettingBusyBlfAudibleAlert>Default</ringSettingBusyBlfAudibleAlert><blfDirectedCallParks/><addOnModules/><userLocale /><networkLocale /><idleTimeout /><authenticationUrl /><directoryUrl /><idleUrl /><informationUrl /><messagesUrl /><proxyServerUrl /><servicesUrl /><services/><softkeyTemplateName/><loginUserId /><defaultProfileName/><enableExtensionMobility>false</enableExtensionMobility><currentProfileName/><loginTime /><loginDuration /><currentConfig><userHoldMohAudioSourceId /><phoneTemplateName uuid=\"{8E1A10FA-A52C-4435-A4EC-540D266C8C37}\">Standard Client Services Framework</phoneTemplateName><mlppDomainId /><mlppIndicationStatus>Off</mlppIndicationStatus><preemption>Disabled</preemption><softkeyTemplateName/><ignorePresentationIndicators>false</ignorePresentationIndicators><singleButtonBarge>Default</singleButtonBarge><joinAcrossLines>Off</joinAcrossLines><callInfoPrivacyStatus>Default</callInfoPrivacyStatus><dndStatus /><dndRingSetting /><dndOption>Ringer Off</dndOption><alwaysUsePrimeLine>Default</alwaysUsePrimeLine><alwaysUsePrimeLineForVoiceMessage>Default</alwaysUsePrimeLineForVoiceMessage><emccCallingSearchSpaceName xsi:nil=\"true\" uuid=\"\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"/><deviceName/><model/><product/><deviceProtocol/><class/><addressMode/><allowAutoConfig/><remoteSrstOption/><remoteSrstIp/><remoteSrstPort/><remoteSipSrstIp/><remoteSipSrstPort/><geolocationInfo/><remoteLocationName/></currentConfig><singleButtonBarge>Default</singleButtonBarge><joinAcrossLines>Off</joinAcrossLines><builtInBridgeStatus>Default</builtInBridgeStatus><callInfoPrivacyStatus>Default</callInfoPrivacyStatus><hlogStatus>On</hlogStatus><ownerUserName/><ignorePresentationIndicators>false</ignorePresentationIndicators><packetCaptureMode>None</packetCaptureMode><packetCaptureDuration>0</packetCaptureDuration><subscribeCallingSearchSpaceName/><rerouteCallingSearchSpaceName/><allowCtiControlFlag>true</allowCtiControlFlag><presenceGroupName uuid=\"{AD243D17-98B4-4118-8FEB-5FF2E1B781AC}\">Standard Presence group</presenceGroupName><unattendedPort>false</unattendedPort><requireDtmfReception>false</requireDtmfReception><rfc2833Disabled>false</rfc2833Disabled><certificateOperation>No Pending Operation</certificateOperation><authenticationMode /><keySize /><keyOrder /><ecKeySize /><authenticationString /><certificateStatus>None</certificateStatus><upgradeFinishTime /><deviceMobilityMode>Default</deviceMobilityMode><roamingDevicePoolName/><remoteDevice>false</remoteDevice><dndOption>Ringer Off</dndOption><dndRingSetting /><dndStatus>false</dndStatus><isActive>true</isActive><isDualMode>false</isDualMode><mobilityUserIdName/><phoneSuite>Default</phoneSuite><phoneServiceDisplay>Default</phoneServiceDisplay><isProtected>false</isProtected><mtpRequired>false</mtpRequired><mtpPreferedCodec>711ulaw</mtpPreferedCodec><dialRulesName/><sshUserId/><digestUser/><outboundCallRollover>No Rollover</outboundCallRollover><hotlineDevice>false</hotlineDevice><secureInformationUrl /><secureDirectoryUrl /><secureMessageUrl /><secureServicesUrl /><secureAuthenticationUrl /><secureIdleUrl /><alwaysUsePrimeLine>Default</alwaysUsePrimeLine><alwaysUsePrimeLineForVoiceMessage>Default</alwaysUsePrimeLineForVoiceMessage><featureControlPolicy/><deviceTrustMode>Not Trusted</deviceTrustMode><confidentialAccess><confidentialAccessMode /><confidentialAccessLevel>-1</confidentialAccessLevel></confidentialAccess><requireOffPremiseLocation>false</requireOffPremiseLocation><cgpnIngressDN/><useDevicePoolCgpnIngressDN>true</useDevicePoolCgpnIngressDN><msisdn /><enableCallRoutingToRdWhenNoneIsActive>false</enableCallRoutingToRdWhenNoneIsActive><wifiHotspotProfile/><wirelessLanProfileGroup/><elinGroup/><enableActivationID>false</enableActivationID><activationIDStatus /><mraServiceDomain/><allowMraMode>false</allowMraMode></phone></return></ns:getPhoneResponse></soapenv:Body></soapenv:Envelope>"]
directory_number:
  description: Primary Directory Number of the User Line associated to the Phone Device
  type: str
  sample:
    directory_number": "10001"
  returned: success
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule


def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        device_name=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(changed=False, 
                  raw_content="", 
                  directory_number="")

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
        <soapenv:Header/>
        <soapenv:Body>
            <ns:getPhone>
                <name>{ module.params["device_name"] }</name>
                  <returnedTags ctiid="?" uuid="?">
                      <!--Optional:-->
                      <lines>
                        <!--You have a CHOICE of the next 2 items at this level-->
                        <!--Zero or more repetitions:-->
                        <line ctiid="?" uuid="?">
                            <!--Optional:-->
                            <index>?</index>
                            <!--Optional:-->
                            <dirn uuid="?">
                              <!--Optional:-->
                              <pattern>?</pattern>
                            </dirn>
                        </line>
                      </lines>
                  </returnedTags>
            </ns:getPhone>
        </soapenv:Body>
    </soapenv:Envelope>"""

    response = requests.post(
        url,
        data=data,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content"] = response.content
    root = ET.fromstring(response.content)

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result

    try:
        xpath_query = ".//*[index='1']/dirn/pattern"
        primary_dn = root.find(xpath_query)
         
        result["primary_dn"] = primary_dn.text

    except:
        axl_error_code = root.find(".//axlcode")
        axl_error_message = root.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""ERROR: There is not any DN associated to this Phone Device""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
