#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2023, Jordi Bericat <jordi.bericat@global.ntt>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

DOCUMENTATION = r"""
---
module: cisco.cucm.get_line_group_members
short_description: Given a LG, this module returns it's associated DN members
description: 
  -  Given a Line Group (LG), this module returns it's associated Directory Number (DN) members if the provided LG was found. If the LG is not present, the module fails.
version_added: "1.4.0"
options:
  line_group:
    description: Line Group search query
    required: true
    type: str
extends_documentation_fragment:
  - cisco.cucm.common
"""

EXAMPLES = r"""
- name: Get Line Group members
  cisco.cucm.get_line_group_members:
    line_group: "LG_1101_9XXXXXXXX"
    provider:
      host: cucm.my-domain.net
      user: admin
      password: my_super_pass
      port: 8443
      validate_certs: false
  delegate_to: localhost
  register: get_line_group_members_results
"""

RETURN = r"""
members:
  description: List of Directory Numbers (Line Group members). If there are no members associated to the LG, the "members" return value is an empty list
  type: list
  sample:
    members:
      - "10000"
      - "10001"
  returned: success
raw_content:
  description: The raw xml response received from the SOAP AXL request used to retrieve the Line Group name
  type: str
  returned: always
  sample: 
    raw_content: "<?xml version='1.0' encoding='UTF-8'?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\"><soapenv:Body><ns:getLineGroupResponse xmlns:ns=\"http://www.cisco.com/AXL/API/12.5\"><return><lineGroup uuid=\"{4CE8096E-34B5-B14A-3F30-2A08CB975D66}\"><distributionAlgorithm>Longest Idle Time</distributionAlgorithm><rnaReversionTimeOut>10</rnaReversionTimeOut><huntAlgorithmNoAnswer>Try next member; then, try next group in Hunt List</huntAlgorithmNoAnswer><huntAlgorithmBusy>Try next member; then, try next group in Hunt List</huntAlgorithmBusy><huntAlgorithmNotAvailable>Try next member; then, try next group in Hunt List</huntAlgorithmNotAvailable><members><member uuid=\"{A37D5C91-8D82-9392-6FCC-13511E5F90CA}\"><lineSelectionOrder>0</lineSelectionOrder><directoryNumber uuid=\"{3945F993-89E2-2301-A0E6-528E32744A77}\"><pattern>10000</pattern><routePartitionName/></directoryNumber></member><member uuid=\"{91890E5A-7DE4-0EFB-29DA-210F6D1AB525}\"><lineSelectionOrder>1</lineSelectionOrder><directoryNumber uuid=\"{992218E0-D513-FB04-7B39-E28A34607D45}\"><pattern>10001</pattern><routePartitionName/></directoryNumber></member></members><name>LG_1101_9XXXXXXXX</name><autoLogOffHunt>false</autoLogOffHunt></lineGroup></return></ns:getLineGroupResponse></soapenv:Body></soapenv:Envelope>"
"""

import ast
import xml.etree.ElementTree as ET

import requests
from ansible.module_utils.basic import AnsibleModule

def run_module():
    module_args = dict(
        provider=dict(
            host=dict(type="str", required=True),
            user=dict(type="str", required=True, no_log=True),
            password=dict(type="str", required=True, no_log=True),
            port=dict(type="str", required=False, default="8443"),
            validate_certs=dict(type="bool", required=False, default="True"),
            no_log=True,
        ),
        line_group=dict(type="str", required=True),
    )

    # seed the result dict in the object
    # we primarily care about changed and state
    # changed is if this module effectively modified the target
    # state will include any data that you want your module to pass back
    # for consumption, for example, in a subsequent task
    result = dict(
        changed=False,
        raw_content="",
        members="",
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args, supports_check_mode=False
    )

    # if the user is working with this module in only check mode we do not
    # want to make any changes to the environment, just return the current
    # state with no modifications
    if module.check_mode:
        module.exit_json(**result)

    # manipulate or modify the state as needed (this is going to be the
    # part where your module will do what it needs to do)

    provider_data = ast.literal_eval(module.params["provider"])

    url = (
        "https://"
        + provider_data["host"]
        + ":"
        + str(provider_data["port"])
        + "/axl/"
    )

    data_lg_members = f"""
    <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:ns="http://www.cisco.com/AXL/API/12.5">
      <soapenv:Header/>
      <soapenv:Body>
        <ns:getLineGroup>
          <name>{ module.params["line_group"]}</name>
        </ns:getLineGroup>
      </soapenv:Body>
    </soapenv:Envelope>
    """

    response_lg_members = requests.post(
        url,
        data=data_lg_members,
        auth=(provider_data["user"], provider_data["password"]),
        verify=provider_data["validate_certs"],
    )

    result["raw_content_members"] = response_lg_members.content

    root_members = ET.fromstring(response_lg_members.content)
    lg_members_parameters = [
        {
            "option": "members",
            "xpath_query": ".//*/pattern",
        },
    ]

    # during the execution of the module, if there is an exception or a
    # conditional state that effectively causes a failure, run
    # AnsibleModule.fail_json() to pass in the message and the result
    
    try:
        for item in lg_members_parameters:
            lg_members_option = root_members.findall(item["xpath_query"])
            result[item["option"]] = [
                pattern.text for pattern in lg_members_option
            ]
    except:
        axl_error_code = root_members.find(".//axlcode")
        axl_error_message = root_members.find(".//axlmessage")
        if type(axl_error_code) and type(axl_error_message) is dict:
            module.fail_json(
                msg=f"""AXL code { axl_error_code.text } - { axl_error_message.text }""",
                **result,
            )
        else:
            module.fail_json(
                msg=f"""ERROR: No members on this Line Group""",
                **result,
            )

    # use whatever logic you need to determine whether or not this module
    # made any modifications to your target
    result["changed"] = False

    # in the event of a successful module execution, you will want to
    # simple AnsibleModule.exit_json(), passing the key/value results
    module.exit_json(**result)


def main():
    0


run_module()

if __name__ == "__main__":
    main()
